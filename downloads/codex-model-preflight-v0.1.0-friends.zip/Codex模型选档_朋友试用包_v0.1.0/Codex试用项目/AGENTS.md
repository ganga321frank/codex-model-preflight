﻿# 试用项目

本目录仅用于演示 Codex Model Preflight。订单样例.csv 为虚构数据。按用户要求处理试用任务，生成的文件放在本项目的“试用输出”文件夹；保留输入样例与技能文件。

<!-- codex-model-preflight:start -->
独立大任务开始前调用 $codex-model-preflight，推荐模型、推理档位与速度，并在实质执行前暂停一次；本任务已选定或接受设置、或用户要求不要暂停时直接继续。普通追问和已接受的继续执行不重复分档；“继续”不代表模型切换已验证。
<!-- codex-model-preflight:end -->
